﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Navigation;
using LibraryFraction;

namespace Evaluatie3
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();


            //Eventhandlers for each operation
            ADDFraction1Numerator.TextChanged += UpdateAdditionResult;
            ADDFraction1Denominator.TextChanged += UpdateAdditionResult;
            ADDFraction2Numerator.TextChanged += UpdateAdditionResult;
            ADDFraction2Denominator.TextChanged += UpdateAdditionResult;

            SUBFraction1Numerator.TextChanged += UpdateSubtractionResult;
            SUBFraction1Denominator.TextChanged += UpdateSubtractionResult;
            SUBFraction2Numerator.TextChanged += UpdateSubtractionResult;
            SUBFraction2Denominator.TextChanged += UpdateSubtractionResult;

            MULTIFraction1Numerator.TextChanged += UpdateMultiplicationResult;
            MULTIFraction1Denominator.TextChanged += UpdateMultiplicationResult;
            MULTIFraction2Numerator.TextChanged += UpdateMultiplicationResult;
            MULTIFraction2Denominator.TextChanged += UpdateMultiplicationResult;

            DIVFraction1Numerator.TextChanged += UpdateDivisionResult;
            DIVFraction1Denominator.TextChanged += UpdateDivisionResult;
            DIVFraction2Numerator.TextChanged += UpdateDivisionResult;
            DIVFraction2Denominator.TextChanged += UpdateDivisionResult;

            INVFractionNumerator.TextChanged += UpdateInvertResult;
            INVFractionDenominator.TextChanged += UpdateInvertResult;

            RECFractionNumerator.TextChanged += UpdateReciprocalResult;
            RECFractionDenominator.TextChanged += UpdateReciprocalResult;
        }

        // Event handler to update results for each operation
        private void UpdateAdditionResult(object sender, RoutedEventArgs e)
        {
            UpdateResult(ADDFraction1Numerator, ADDFraction1Denominator, ADDFraction2Numerator, ADDFraction2Denominator, ADDResultNumerator, ADDResultDenominator, (fraction1, fraction2) => fraction1.Add(fraction2));
        }

        private void UpdateSubtractionResult(object sender, RoutedEventArgs e)
        {
            UpdateResult(SUBFraction1Numerator, SUBFraction1Denominator, SUBFraction2Numerator, SUBFraction2Denominator, SUBResultNumerator, SUBResultDenominator, (fraction1, fraction2) => fraction1.Subtract(fraction2));
        }

        private void UpdateMultiplicationResult(object sender, RoutedEventArgs e)
        {
            UpdateResult(MULTIFraction1Numerator, MULTIFraction1Denominator, MULTIFraction2Numerator, MULTIFraction2Denominator, MULTIResultNumerator, MULTIResultDenominator, (fraction1, fraction2) => fraction1.Multiply(fraction2));
        }

        private void UpdateDivisionResult(object sender, RoutedEventArgs e)
        {
            UpdateResult(DIVFraction1Numerator, DIVFraction1Denominator, DIVFraction2Numerator, DIVFraction2Denominator, DIVResultNumerator, DIVResultDenominator, (fraction1, fraction2) => fraction1.Divide(fraction2));
        }

        private void UpdateInvertResult(object sender, RoutedEventArgs e)
        {
            UpdateSingleOperandResult(INVFractionNumerator, INVFractionDenominator, INVResultNumerator, INVResultDenominator, fraction => fraction.Invert());
        }

        private void UpdateReciprocalResult(object sender, RoutedEventArgs e)
        {
            UpdateSingleOperandResult(RECFractionNumerator, RECFractionDenominator, RECResultNumerator, RECResultDenominator, fraction => fraction.Reciprocal());
        }

        private void UpdateResult(TextBox numerator1TextBox, TextBox denominator1TextBox, TextBox numerator2TextBox, TextBox denominator2TextBox, TextBox resultNumeratorTextBox, TextBox resultDenominatorTextBox, Func<Fraction, Fraction, Fraction> operation)
        {
            try
            {
                if (!int.TryParse(numerator1TextBox.Text, out int numerator1) ||
                    !int.TryParse(denominator1TextBox.Text, out int denominator1) ||
                    !int.TryParse(numerator2TextBox.Text, out int numerator2) ||
                    !int.TryParse(denominator2TextBox.Text, out int denominator2))
                {
                    return;
                }

                Fraction fraction1 = new Fraction(numerator1, denominator1);
                Fraction fraction2 = new Fraction(numerator2, denominator2);

                Fraction result = operation(fraction1, fraction2);

                resultNumeratorTextBox.Text = result.Numerator.ToString();
                resultDenominatorTextBox.Text = result.Denominator.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateSingleOperandResult(TextBox numeratorTextBox, TextBox denominatorTextBox, TextBox resultNumeratorTextBox, TextBox resultDenominatorTextBox, Func<Fraction, Fraction> operation)
        {
            try
            {
                if (!int.TryParse(numeratorTextBox.Text, out int numerator) ||
                    !int.TryParse(denominatorTextBox.Text, out int denominator))
                {
                    return;
                }

                Fraction fraction = new Fraction(numerator, denominator);

                Fraction result = operation(fraction);

                resultNumeratorTextBox.Text = result.Numerator.ToString();
                resultDenominatorTextBox.Text = result.Denominator.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
            e.Handled = true;
        }



    }
}

