﻿using System;
using LibraryFraction;

namespace FractionConsoleApplication
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //This application checks if the library "LibraryFraction" works correctly. It makes two fractions and performs the operations. 
            //Create two fractions
            Fraction oneFourth = new Fraction(1, 4);
            Fraction twoFourth = new Fraction(2, 4);

            //Perform the four basic operations
            Fraction sum = oneFourth.Add(twoFourth);
            Fraction difference = oneFourth.Subtract(twoFourth);
            Fraction product = oneFourth.Multiply(twoFourth);
            Fraction quotient = oneFourth.Divide(twoFourth);

            // Output results
            Console.WriteLine($"Sum as fraction: {sum}");            // Output: 3 / 4
            Console.WriteLine($"Difference as fraction: {difference}");// Output: -1 / 4
            Console.WriteLine($"Product as fraction: {product}");      // Output: 1 / 8
            Console.WriteLine($"Quotient as fraction: {quotient}");    // Output: 1 / 2

            Console.WriteLine($"Sum Result: {sum.Result()}");                  // Output: 0.75
            Console.WriteLine($"Difference Result: {difference.Result()}");    // Output: -0.25
            Console.WriteLine($"Product Result: {product.Result()}");          // Output: 0.125
            Console.WriteLine($"Quotient Result: {quotient.Result()}");        // Output: 0.5
        }
    }
}
