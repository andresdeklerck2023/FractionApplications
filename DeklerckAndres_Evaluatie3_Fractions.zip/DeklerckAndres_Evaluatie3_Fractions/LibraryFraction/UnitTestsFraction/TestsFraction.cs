using Xunit;
using LibraryFraction;

namespace FractionUnitTests
{
    public class FractionTests
    {
        // Test for the constructor
        [Fact]
        public void TestConstructor()
        {
            Fraction fraction = new Fraction(1, 2);
            Assert.Equal(1, fraction.Numerator);
            Assert.Equal(2, fraction.Denominator);
        }

        // Tests for all the operations + invert + reciprocal
        [Fact]
        public void TestAddition()
        {
            Fraction fraction1 = new Fraction(1, 2);
            Fraction fraction2 = new Fraction(1, 4);
            Fraction sum = fraction1.Add(fraction2);
            Assert.Equal(new Fraction(3, 4), sum);
        }

        [Fact]
        public void TestSubtraction()
        {
            Fraction fraction1 = new Fraction(3, 4);
            Fraction fraction2 = new Fraction(1, 4);
            Fraction difference = fraction1.Subtract(fraction2);
            Assert.Equal(new Fraction(1, 2), difference);
        }

        [Fact]
        public void TestMultiplication()
        {
            Fraction fraction1 = new Fraction(1, 2);
            Fraction fraction2 = new Fraction(3, 4);
            Fraction product = fraction1.Multiply(fraction2);
            Assert.Equal(new Fraction(3, 8), product);
        }

        [Fact]
        public void TestDivision()
        {
            Fraction fraction1 = new Fraction(1, 2);
            Fraction fraction2 = new Fraction(1, 4);
            Fraction quotient = fraction1.Divide(fraction2);
            Assert.Equal(new Fraction(2, 1), quotient);
        }

        [Fact]
        public void TestInvert()
        {
            Fraction fraction1 = new Fraction(1, 2);
            Fraction result = fraction1.Invert();
            Assert.Equal(new Fraction(-1, 2), result);
        }

        [Fact]
        public void TestReciprocal()
        {
            Fraction fraction1 = new Fraction(1, 2);
            Fraction result = fraction1.Reciprocal();
            Assert.Equal(new Fraction(2, 1), result);
        }
    }
}
