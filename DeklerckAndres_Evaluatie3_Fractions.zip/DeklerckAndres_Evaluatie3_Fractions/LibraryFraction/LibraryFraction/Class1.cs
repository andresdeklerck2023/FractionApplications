﻿namespace LibraryFraction
{
    public class Class1
    {

    }
}
