﻿using System;

namespace LibraryFraction
{
    public class Fraction
    {
        public int Numerator { get; }
        public int Denominator { get; }

        public Fraction(int numerator, int denominator)
        {
            if (denominator == 0)
            {
                throw new ArgumentException("Denominator cannot be zero.");
            }

            Numerator = numerator;
            Denominator = denominator;
        }

        public Fraction Add(Fraction other)
        {
            int newNumerator = Numerator * other.Denominator + other.Numerator * Denominator;
            int newDenominator = Denominator * other.Denominator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        public Fraction Subtract(Fraction other)
        {
            int newNumerator = Numerator * other.Denominator - other.Numerator * Denominator;
            int newDenominator = Denominator * other.Denominator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        public Fraction Multiply(Fraction other)
        {
            int newNumerator = Numerator * other.Numerator;
            int newDenominator = Denominator * other.Denominator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        public Fraction Divide(Fraction other)
        {
            if (other.Numerator == 0)
            {
                throw new DivideByZeroException("Cannot divide by zero.");
            }

            int newNumerator = Numerator * other.Denominator;
            int newDenominator = Denominator * other.Numerator;
            return new Fraction(newNumerator, newDenominator).Simplify();
        }

        public Fraction Reciprocal()
        {
            return new Fraction(Denominator, Numerator);
        }

        public Fraction Invert()
        {
            return new Fraction(-Numerator, Denominator);
        }

        public Fraction Simplify()
        {
            int gcf = GCF(Math.Abs(Numerator), Math.Abs(Denominator));
            int simplifiedNumerator = Numerator / gcf;
            int simplifiedDenominator = Denominator / gcf;
            return new Fraction(simplifiedNumerator, simplifiedDenominator);
        }

        private int GCF(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        public double Result()
        {
            return (double)Numerator/Denominator;
        }

        public override string ToString()
        {
            return $"{Numerator}/{Denominator}";
        }
    }
}
