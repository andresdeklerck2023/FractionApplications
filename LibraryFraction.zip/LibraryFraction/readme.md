# Fraction Calculator

## Project Description
The Fraction Calculator is a simple application that allows users to perform basic arithmetic operations on fractions. It includes functionality for addition, subtraction, multiplication, and division of fractions, as well as finding inverses and reciprocals. The solution consists of a single project containing the calculator application.

## Author
Deklerck Andres

## Screenshots
[Include screenshots of the application here]

## Setup and Usage
To use the Fraction Calculator, you will need Visual Studio 2022. Simply clone the repository, open the solution in Visual Studio 2022 , and run the application.

## Unit Tests
Unit tests are included to ensure the correctness of the fraction arithmetic operations. The tests cover every operation in this project (addition, subtraction, multiplication, division, inverse, and reciprocal).
To run the unit tests, navigate to the test project in Visual Studio, and run all tests.

## UML Class Diagram of Fraction
[Include UML class diagram of the Fraction class here]

## Future Improvements
- Improve user interface design for better usability and making it more user-friendly.
- Add support for mixed numbers and improper fractions.
